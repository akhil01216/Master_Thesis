Hello,

This project was to estimate Soil Organic Carbon from proximal and reote sensing data. I have attached the data used and results.

1. Two main folders named "Sentinel_2A" and "Veris_MSP3", subfolders are named "Data" and "results"

2. Data folder contains the raw data from Veris MSP3 and Sentinel-2A

3. Results are created based on 30 patches (folder name - patches30) and complete field (folder name Study_area)
	3.1 patches_30 folder contains
		a. SOC in tiff, shape file(points) and image format
	3.2 Study area folder contains
		a. SOC in tiff and image format

Please feel free to contact me, if you need any clarification.


Thank you,

Akhil Chandran
akhil01216@gmail.com
+49 1789320255